﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//TODO add dispose to all deleted items;
namespace Questionary
{
    public partial class Panel1 : UserControl
    {
        private int _numOfResponses = 0;
        private string boxType { get; set; }
        public Panel1(int number, string choiceOption)
        {
            InitializeComponent();
            chbxWrap.Checked = true;
            boxType = choiceOption;
            SetUpToolBar(choiceOption);

        }

        private void SetUpToolBar(string choiceOption)
        {
            if (choiceOption == "Likert" || choiceOption == "TextBox" || choiceOption == "Line"
                || choiceOption == "Paragraph" || choiceOption == "DropDown" || choiceOption == "DateTime")
            {
                menuStripEdit.Items.Remove(txtOptiontxt);
                menuStripEdit.Items.Remove(cbFlowDirection);
                menuStripEdit.Items.Remove(alignToolStripMenuItem);
                if (choiceOption != "Likert")
                    menuStripEdit.Items.Remove(toolStripTextAmoun);

                chbxWrap.Visible = false;
            }
            else
            {
                menuStripEdit.Items.Remove(toolStripTextAmoun);
                //menuStripEdit.Items.Remove()
            }
            if (choiceOption == "DropDown")
            {
                Label lb = new Label();
                lb.Text = "Add List of Options, comma separated: ";
                flpResponse.Controls.Add(lb);
                lb.AutoSize = true;

                RichTextBox rb = new RichTextBox();
                rb.Name = "rbx" + _numOfResponses;
                flpResponse.Controls.Add(rb);
                rb.Width = flpResponse.Width / 2;

                Button bt = new Button();
                bt.Name = "btn" + _numOfResponses;
                bt.Click += new EventHandler(this.btn_CreateDropDown_Click);
                bt.Text = "Set";
                bt.BackColor = Color.Azure;
                flpResponse.Controls.Add(bt);

                ComboBox cb = new ComboBox();
                cb.Name = "cb" + _numOfResponses;
                cb.DropDownStyle = ComboBoxStyle.DropDownList;
                flpResponse.Controls.Add(cb);
                btnAdd.Visible = false;
                btnDelete.Visible = false;
            }
            if (choiceOption == "header")
            {
                txtOptiontxt.Visible = false;
                txtVarName.Visible = false;
                txtVarName.Text = "N";
                cbRequired.Visible = false;
                chbxWrap.Visible = false;
                menuStripEdit.Items.Remove(txtOptiontxt);
                menuStripEdit.Items.Remove(cbFlowDirection);
                menuStripEdit.Items.Remove(alignToolStripMenuItem);
                moFontResponse.Visible = false;
                btnAdd.Visible = false;
                btnDelete.Visible = false;

                BlockHeader bl = new BlockHeader();
                flpResponse.Controls.Add(bl);
                flpResponse.Height = 0;
                this.Height = 120;
                txtQuestionText.Name = "BlockHeader";
            }
            if (choiceOption == "textFormQuest")
            {
                TextFormatQuest tfq = new TextFormatQuest();
                
                tfq.Width = flpResponse.Width;
                flpResponse.Controls.Add(tfq);

            }
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (boxType == "Single Answer")
            {
                RadioButton rbtn = new RadioButton();
                rbtn.Name = "rbtn" + _numOfResponses;
                rbtn.Text = txtOptiontxt.Text;
                rbtn.AutoSize = true;
                flpResponse.Controls.Add(rbtn);
                //txtQuestionText.Name = "RadioButton";

            }
            else if (boxType == "Multi Answer")
            {
                CheckBox cb = new CheckBox();
                cb.Name = "cb" + _numOfResponses;
                cb.Text = txtOptiontxt.Text;
                cb.AutoSize = true;
                menuStripEdit.Items.Remove(toolStripTextAmoun);
                flpResponse.Controls.Add(cb);
               
            }
            else if (boxType == "Likert")
            {
                int likertSize = Convert.ToInt32(toolStripTextAmoun.Text);
                int luWidth = ClientSize.Width / (likertSize + 5);//1250 
             
                //TODO: 
                for (int i = 0; i < likertSize; i++)
                {
                    LikertUnit lu = new LikertUnit();
                    flpResponse.Width = ClientSize.Width;
                    lu.Name = "lu" + _numOfResponses + " " + i;
                    lu.Width = luWidth;
                    lu.BackColor = flpResponse.BackColor;

                    TextBox tb = (TextBox)lu.Controls.Find("luText", true).FirstOrDefault();
                    tb.Text = (i + 1).ToString();
                    flpResponse.Controls.Add(lu);


                }
                flpResponse.FlowDirection = FlowDirection.LeftToRight;
                flpResponse.AutoSize = true;

                btnAdd.Enabled = false;
            }
            else if (boxType == "Line")
            {
                LineControl lc = new LineControl();
                //txtQuestionText.Name = "Line";
                lc.Name = "lc" + _numOfResponses;
                //TODO: Add cusom event handler for text?
                flpResponse.Controls.Add(lc);
                //flpResponse.AutoSize = true;
                flpResponse.AutoScroll = true;
                lc.Width = ClientSize.Width;
                //foreach (Control c in lc.Controls)
                //{

                //}

            }
            else if (boxType == "TextBox") //TODO: let the user deside the size?
            {
                TextBox tb = new TextBox();
                tb.Name = "tb" + _numOfResponses;
                tb.Anchor = AnchorStyles.Left | AnchorStyles.Right;
                tb.Width = flpResponse.Width - 100;
                flpResponse.Controls.Add(tb);
                flpResponse.AutoScroll = true;
                //txtQuestionText.Name = "TexBox";
            }
            else if (boxType == "Paragraph")
            {
                RichTextBox rb = new RichTextBox();
                rb.Name = "rb" + _numOfResponses;
                rb.Height = flpResponse.Height - 20;
                rb.Width = flpResponse.Width - 20;
                flpResponse.Controls.Add(rb);

            }

            else if (boxType == "DateTime")
            {

                DateTimePicker dp = new DateTimePicker();
                dp.Name = "dp" + _numOfResponses;
                flpResponse.Controls.Add(dp);

            }
            else if (boxType == "header")
            {


            }
            else if (boxType == "TextQuestion")
            {
                TextFormatQuest txq = new TextFormatQuest();
                flpResponse.Controls.Add(txq);
            }


            _numOfResponses++;
        }

        private void btn_CreateDropDown_Click(object sender, EventArgs e)
        {
            Button bt = (Button)sender;
            var str = bt.Name.Substring(3, 1);
            RichTextBox rb = flpResponse.Controls.Find(("rbx" + str), true).FirstOrDefault() as RichTextBox;
            List<string> cbList = rb.Text.Split(',').ToList();

            if (cbList.Count > 0)
            {
                ComboBox cb = flpResponse.Controls.Find(("cb" + str), true).FirstOrDefault() as ComboBox;
                cb.Items.Clear();
                cb.Items.Insert(0, "Select item:");
                cb.SelectedIndex = 0;
                int newWidth = 0;
                int width = cb.DropDownWidth;
                foreach (String item in cbList)
                {
                    cb.Items.Add(item);
                    newWidth = TextRenderer.MeasureText(item.ToString(), cb.Font).Width + SystemInformation.VerticalScrollBarWidth;
                    if (width < newWidth)
                    {
                        width = newWidth;
                    }

                }
                cb.Width = width;
            }
        }

        private void directionToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;

            flpResponse.FlowDirection = Util.MapFlowDirection(txt);
        }

        private void btnDelete_Click(object sender, EventArgs e) //refactor to accept all types;
        {
            if (_numOfResponses != 0)
                _numOfResponses--;
            if (boxType == "Single Answer")
            {
                RadioButton rbtn = this.Controls.Find("rbtn" + (_numOfResponses), true).FirstOrDefault() as RadioButton;
                flpResponse.Controls.Remove(rbtn);
                rbtn.Dispose();
            }
            else if (boxType == "Multi Answer")
            {
                CheckBox cb = this.Controls.Find("cb" + (_numOfResponses), true).FirstOrDefault() as CheckBox;
                flpResponse.Controls.Remove(cb);
                cb.Dispose();
            }
            else if (boxType == "Likert")
            {
                List<LikertUnit> luList = flpResponse.Controls.OfType<LikertUnit>().ToList();
                foreach (LikertUnit lu in luList)
                {
                    flpResponse.Controls.Remove(lu);
                    lu.Dispose();
                }
                btnAdd.Enabled = true;
            }
            else if (boxType == "Line") //TODO: check for nulls befor dispose;
            {
                LineControl lc = this.Controls.Find("lc" + (_numOfResponses), true).FirstOrDefault() as LineControl;
                flpResponse.Controls.Remove(lc);
                lc.Dispose();
            }
            else if (boxType == "TextBox")
            {
                TextBox tb = this.Controls.Find("tb" + (_numOfResponses), true).FirstOrDefault() as TextBox;

                flpResponse.Controls.Remove(tb);
                tb.Dispose();

            }
            else if (boxType == "Paragraph")
            {
                RichTextBox tb = this.Controls.Find("rb" + (_numOfResponses), true).FirstOrDefault() as RichTextBox;

                flpResponse.Controls.Remove(tb);
                tb.Dispose();

            }

            else if (boxType == "DateTime")
            {
                DateTimePicker dtp = this.Controls.Find("dp" + (_numOfResponses), true).FirstOrDefault() as DateTimePicker;

                flpResponse.Controls.Remove(dtp);
                dtp.Dispose();

            }
        }
        private void chbxWrap_Click(object sender, EventArgs e)
        {
            if (chbxWrap.Checked)
            {
                flpResponse.WrapContents = true;
                flpResponse.AutoSize = false;
                flpResponse.AutoScroll = false;
            }

            else
            {
                flpResponse.WrapContents = false;
                flpResponse.AutoSize = false;
                flpResponse.AutoScroll = true;
            }
        }

        private void moFontLabel_Click(object sender, EventArgs e)
        {

            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                txtQuestionText.Font = fd.Font;

            }

        }

        private void moFontResponse_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                flpResponse.Font = fd.Font;

            }
        }

        private void moTextAlign_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;

            txtQuestionText.TextAlign = Util.MapTextAlign(txt);
        }

        private void borderToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;
            flpResponse.BorderStyle = Util.MapBorderStyle(txt);

        }

        private void alignToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string text = e.ClickedItem.Text;
            foreach (Control c in flpResponse.Controls)
            {

                if (c is CheckBox)
                {

                    SetChekBoxProperties(c as CheckBox, text);

                }
                else if (c is RadioButton)
                {
                    SetChekBoxProperties(c as RadioButton, text);
                }
            }
        }

        private void SetChekBoxProperties(CheckBox cb, string text)
        {
            switch (text)
            {
                case "Bottom Left":
                    cb.CheckAlign = ContentAlignment.BottomLeft;
                    return;
                case "Bottom Right":
                    cb.CheckAlign = ContentAlignment.BottomRight;
                    return;
                case "Bottom Center":
                    cb.CheckAlign = ContentAlignment.BottomCenter;
                    return;
                case "Middle Left":
                    cb.CheckAlign = ContentAlignment.MiddleLeft;
                    return;
                case "Middle Right":
                    cb.CheckAlign = ContentAlignment.MiddleRight;
                    return;
                case "Middle Center":
                    cb.CheckAlign = ContentAlignment.MiddleCenter;
                    return;
                case "Top Left":
                    cb.CheckAlign = ContentAlignment.TopLeft;
                    return;
                case "Top Right":
                    cb.CheckAlign = ContentAlignment.TopRight;
                    return;
                case "Top Center":
                    cb.CheckAlign = ContentAlignment.TopCenter;
                    return;
            }
        }
        private void SetChekBoxProperties(RadioButton rb, string text)
        {
            switch (text)
            {
                case "Bottom Left":
                    rb.CheckAlign = ContentAlignment.BottomLeft;
                    return;
                case "Bottom Right":
                    rb.CheckAlign = ContentAlignment.BottomRight;
                    return;
                case "Bottom Center":
                    rb.CheckAlign = ContentAlignment.BottomCenter;
                    return;
                case "Middle Left":
                    rb.CheckAlign = ContentAlignment.MiddleLeft;
                    return;
                case "Middle Right":
                    rb.CheckAlign = ContentAlignment.MiddleRight;
                    return;
                case "Middle Center":
                    rb.CheckAlign = ContentAlignment.MiddleCenter;
                    return;
                case "Top Left":
                    rb.CheckAlign = ContentAlignment.TopLeft;
                    return;
                case "Top Right":
                    rb.CheckAlign = ContentAlignment.TopRight;
                    return;
                case "Top Center":
                    rb.CheckAlign = ContentAlignment.TopCenter;
                    return;
            }
        }

        private void toolStripTextAmoun_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(toolStripTextAmoun.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                toolStripTextAmoun.Text = toolStripTextAmoun.Text.Remove(toolStripTextAmoun.Text.Length - 1);
            }
        }

        private void Panel1_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void txtQuestionText_MouseClick(object sender, EventArgs e)
        {
          
        }

        private void txtQuestionText_MouseLeave(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Enter Question Text";
                tb.ForeColor = Color.LightGray;
            }
        }

        private void txtVarName_MouseClick(object sender, MouseEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "Variable Name")
            {
                tb.Text = "";
                tb.ForeColor = Color.Black;
            }
        }

        private void txtVarName_MouseLeave(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "")
            {
                tb.Text = "Variable Name";
                tb.ForeColor = Color.LightGray;
            }
        }

        private void txtQuestionText_MouseClick(object sender, MouseEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == "Enter Question Text")
            {
                tb.Text = "";
                tb.ForeColor = Color.Black;
            }
        }

       
    }
}
