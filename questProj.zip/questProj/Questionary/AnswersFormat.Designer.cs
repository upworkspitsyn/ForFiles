﻿namespace Questionary
{
    partial class AnswersFormat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SelectFormat = new System.Windows.Forms.Label();
            this.CSV = new System.Windows.Forms.Button();
            this.TXT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SelectFormat
            // 
            this.SelectFormat.AutoSize = true;
            this.SelectFormat.Location = new System.Drawing.Point(46, 31);
            this.SelectFormat.Name = "SelectFormat";
            this.SelectFormat.Size = new System.Drawing.Size(144, 13);
            this.SelectFormat.TabIndex = 0;
            this.SelectFormat.Text = "Please select answers format";
            this.SelectFormat.Click += new System.EventHandler(this.SelectFormat_Click);
            // 
            // CSV
            // 
            this.CSV.Location = new System.Drawing.Point(12, 109);
            this.CSV.Name = "CSV";
            this.CSV.Size = new System.Drawing.Size(75, 23);
            this.CSV.TabIndex = 1;
            this.CSV.Text = "CSV";
            this.CSV.UseVisualStyleBackColor = true;
            this.CSV.Click += new System.EventHandler(this.CSV_Click);
            // 
            // TXT
            // 
            this.TXT.Location = new System.Drawing.Point(148, 109);
            this.TXT.Name = "TXT";
            this.TXT.Size = new System.Drawing.Size(75, 23);
            this.TXT.TabIndex = 2;
            this.TXT.Text = "TXT";
            this.TXT.UseVisualStyleBackColor = true;
            this.TXT.Click += new System.EventHandler(this.TXT_Click);
            // 
            // AnswersFormat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(235, 188);
            this.Controls.Add(this.TXT);
            this.Controls.Add(this.CSV);
            this.Controls.Add(this.SelectFormat);
            this.Name = "AnswersFormat";
            this.Text = "AnswersFormat";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SelectFormat;
        private System.Windows.Forms.Button CSV;
        private System.Windows.Forms.Button TXT;
    }
}