﻿namespace Questionary
{
    partial class LineControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textLine = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textLine
            // 
            this.textLine.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textLine.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textLine.Dock = System.Windows.Forms.DockStyle.Top;
            this.textLine.Location = new System.Drawing.Point(0, 0);
            this.textLine.MaximumSize = new System.Drawing.Size(1000, 0);
            this.textLine.MaxLength = 1000;
            this.textLine.MinimumSize = new System.Drawing.Size(1000, 35);
            this.textLine.Multiline = true;
            this.textLine.Name = "textLine";
            this.textLine.Size = new System.Drawing.Size(1000, 35);
            this.textLine.TabIndex = 0;
            this.textLine.WordWrap = false;
            this.textLine.TextChanged += new System.EventHandler(this.textLine_TextChanged);
            this.textLine.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textLine_KeyPress);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.BackColor = System.Drawing.SystemColors.InfoText;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(0, 48);
            this.textBox1.MaximumSize = new System.Drawing.Size(2000, 0);
            this.textBox1.MinimumSize = new System.Drawing.Size(0, 2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(1001, 2);
            this.textBox1.TabIndex = 1;
            // 
            // LineControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textLine);
            this.Name = "LineControl";
            this.Size = new System.Drawing.Size(1003, 53);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textLine;
        private System.Windows.Forms.TextBox textBox1;
    }
}
