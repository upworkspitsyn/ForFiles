﻿(function () {
    document.getElementById('save').addEventListener('click', function (event) {
        event.preventDefault();
        saveAnswers();
    });
})();

function saveAnswers() {
    data = [['Question', 'Answers']];
    valid = true;
    var answers = [].slice.call(document.getElementsByClassName("answer"));
    answers.forEach(getAnswers);
    download();
}

function getAnswers(item, index) {
    switch (item.getAttribute('type')) {
        case "checkbox":
            getCheckBoxAnswer(item);
            break;
        case "radio":
        case "likert":
            getRadioAnswer(item);
            break;
        case "datetime":
        case "textbox":
            getTextBoxAnswer(item);
            break;
        case "rbx":
            getRBXAnswer(item);
            break;
        case "dropdown":
            getDropDownAnswer(item);
            break;
    }
}

function getCheckBoxAnswer(item) {
    var checkboxes = item.getElementsByTagName('input');
    var checkedValues = [item.getAttribute('id')];
    for (var i = 0; checkboxes[i]; ++i) {
        if (checkboxes[i].checked) {
            checkedValues.push(checkboxes[i].value);
        }
    }
    if (item.hasAttribute('required') && checkedValues.length == 1) {
        valid = false;
    }
    data.push(checkedValues);

}

function getRadioAnswer(item) {
    var radios = item.getElementsByTagName('input');
    var checkedValue = [item.getAttribute('id')];
    for (var i = 0; radios[i]; ++i) {
        if (radios[i].checked) {
            checkedValue.push(radios[i].value);
            break;
        }
    }
    if (item.hasAttribute('required') && checkedValue.length == 1) {
        valid = false;
    }
    data.push(checkedValue);
}

function getTextBoxAnswer(item) {
    var inputs = item.getElementsByTagName('input');
    var values = [item.getAttribute('id')];
    for (var i = 0; inputs[i]; ++i) {
        if (inputs[i].value.trim()) {
            values.push(inputs[i].value);
        }
    }
    if (item.hasAttribute('required') && values.length == 1) {
        valid = false;
    }
    data.push(values);
}

function getRBXAnswer(item) {
    var textareas = item.getElementsByTagName('textarea');
    var values = [item.getAttribute('id')];
    for (var i = 0; textareas[i]; ++i) {
        if (textareas[i].value.trim())
            values.push(textareas[i].value);
    }
    if (item.hasAttribute('required') && values.length == 1) {
        valid = false;
    }
    data.push(values);
}

function getDropDownAnswer(item) {
    var select = item.getElementsByTagName('select');
    var value = [item.getAttribute('id')];
    for (var i = 0; select[i]; ++i) {
        if (select[i].selectedIndex != 0) {
            value.push(select[i][select[i].selectedIndex].value);
        }
    }
    if (item.hasAttribute('required') && value.length == 1) {

        valid = false;
    }
    data.push(value);
}

var data = [];
var valid = true;

function download() {
    if (!valid) {
        alert('Please answer all required(*) questions');
        return false;
    }
    var format = '{0}';
    var dataType = '';
    if (format == 'csv')
        dataType = 'text / csv';
    else
        dataType = 'text / plain'

    var _file = '';
    data.forEach(function (row) {
        _file += row.join(';');
        _file += "\n";
    });

    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:' + dataType + ';charset=utf-8,' + encodeURI(_file);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'answers.' + format;
    hiddenElement.click();
}