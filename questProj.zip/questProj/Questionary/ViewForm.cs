﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;


namespace Questionary
{
    public partial class ViewForm : Form
    {
        // private object XlInsertShiftDirection;

        public ViewForm()
        {
            InitializeComponent();
            //this.AutoScroll = true;


        }
        //TODO:set body scrolll back;
        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap image = new Bitmap(Width, Height * 2);
            DrawToBitmap(image, new Rectangle(new Point(0, 0), image.Size));
            int size = ClientSize.Height;
            image.Save(Application.StartupPath + @"\testtest.bmp", System.Drawing.Imaging.ImageFormat.Jpeg);

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void finish_Click(object sender, EventArgs e)
        {


            ViewForm vf = this;
            StringBuilder sb = new StringBuilder();
            string questHeader = vf.Controls[4].Controls[0].Text;

            sb.Append(String.Format("Questionnaire name: {0} \r\n", questHeader));
            int i = 0;
            bool isClean = true;
            int reqNum = 0;
            string answerStr = "";
            Control body = vf.Controls[1].Controls.Find("body", true).FirstOrDefault();
            DialogResult result = MessageBox.Show("Use Variable Names instead of Question Text?",
           "Use Variable names",
            MessageBoxButtons.YesNo);
            List<Control> list = new List<Control>();
            int delete;
            if (result == DialogResult.Yes)

                delete = 1;
            else
                delete = 0;

            //foreach (Control c in body.Controls)
            //{

            //    list.Add(c);
            //}

            for (int j = 0; j < body.Controls.Count; j++)
            {
                //if (body.Controls[j].Text != "N")
                //{
                    if (j != delete)
                    {


                        list.Add(body.Controls[j]);

                    }
                    else
                        delete += 3;
                }
          //  }
          
            foreach (Control c in list)// body control
            {
                if (c.Name == "BlockHeader" || c.Text == "N")
                    continue;

                if (i % 2 == 0)
                {
                    sb.Append(String.Format("Question: {0}\r\n", c.Text));
                    if (c.Name == "Required")
                    {
                        reqNum = i + 1;
                    }
                }
                else
                {
                    if (c.Name == "LineControl")
                    {
                        foreach (Control type in c.Controls)
                        {
                            LineControl lc = type as LineControl;
                            {
                                sb.Append(String.Format("Answer: {0}\r\n", lc.Text.Length > 0 ? lc.Text : "(not given)"));
                                answerStr += lc.Text;
                            }
                        }
                    }
                    else if (c.Name == "TextBox")
                    {

                        foreach (Control type in c.Controls)
                        {
                            TextBox answer = type as TextBox;
                            {
                                sb.Append(String.Format("Answer: {0}\r\n", answer.Text.Length > 0 ? answer.Text : "(not given)"));
                                answerStr += answer.Text;
                            }
                        }
                    }
                    else if (c.Name == "Likert")
                    {
                        int chk = 0;

                        string checkedText = "";
                        foreach (Control type in c.Controls)
                        {
                            LikertUnit answer = type as LikertUnit;
                            if (answer.boxChecked)
                            {
                                chk++;
                                checkedText = answer.boxText;
                            }
                        }
                        if (chk == 0)
                        {
                            sb.Append(String.Format("Answer: {0}\r\n", "(not given)"));
                        }
                        else if (chk == 1)
                        {
                            sb.Append(String.Format("Answer: {0}\r\n", checkedText));
                            answerStr += checkedText;
                        }
                        else
                        {
                            MessageBox.Show("Likert Scale can have only one answer", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                            isClean = false;
                        }

                    }
                    else if (c.Name == "radio")
                    {
                        int chk = 0;
                        foreach (Control line in c.Controls)
                        {

                            RadioButton answer = line as RadioButton;
                            if (answer.Checked)
                            {
                                sb.Append(String.Format("Answer: {0}\r\n", answer.Text));
                                chk++;
                                answerStr += answer.Text;
                            }


                        }
                        if (chk == 0)
                        {
                            sb.Append(String.Format("Answer: {0}\r\n", "(not given)"));
                        }

                    }
                    else if (c.Name == "checkbox")
                    {
                        int chk = 0;
                        foreach (Control line in c.Controls)
                        {

                            CheckBox answer = line as CheckBox;
                            if (answer.Checked)
                            {
                                sb.Append(String.Format("Answer: {0}\r\n", answer.Text));
                                chk++;
                                answerStr += answer.Text;
                            }
                        }
                        if (chk == 0)
                        {
                            sb.Append(String.Format("Answer: {0}\r\n", "(not given)"));
                        }

                    }
                    else if (c.Name == "RichTextBox")
                    {
                        foreach (Control type in c.Controls)
                        {
                            RichTextBox answer = type as RichTextBox;
                            {
                                sb.Append(String.Format("Answer: {0}\r\n", answer.Text.Length > 0 ? answer.Text : "(not given)"));
                                answerStr += answer.Text;
                            }
                        }
                    }
                    else if (c.Name == "DateTime")
                    {
                        foreach (Control type in c.Controls)
                        {
                            DateTimePicker dtp = type as DateTimePicker;
                            string theDate = dtp.Value.ToShortDateString();
                            sb.Append(String.Format("Answer: {0}\r\n", theDate));
                            answerStr += theDate;
                        }

                    }
                    else if (c.Name == "DropDown")
                    {
                        foreach (Control type in c.Controls)
                        {
                            ComboBox cb = type as ComboBox;
                            string text = "";
                            if (cb.SelectedItem != null)
                            {
                                text = cb.SelectedItem.ToString();
                                answerStr += text;
                            }
                            else
                            {
                                text = "Answer not given";
                            }

                            sb.Append(String.Format("Answer: {0}\r\n", text));
                            answerStr += text;
                        }
                    }
                    if (i == reqNum)
                    {
                        if (String.IsNullOrEmpty(answerStr))
                        {
                            MessageBox.Show("Please fill out all fields marked as (*)", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                            isClean = false;
                        }
                    }
                }
                i++;
                answerStr = "";
            }
            if (isClean)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "Text File | *.txt| Excel Document| *.xls"; //"JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif";


                if (save.ShowDialog() == DialogResult.OK)
                {
                    switch (save.FilterIndex)
                    {
                        case 1:
                            SaveFileAsText(sb, save);
                            break;
                        case 2:
                            SaveFileAsExcel(sb, save);

                            break;

                    }
                }
            }
        }

        private void SaveFileAsExcel(StringBuilder sb, SaveFileDialog save)
        {
            Excel.Application xlApp = new Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            if (xlApp == null)
            {
                MessageBox.Show("Unable to open the Excel program. Save file as Text", "Error",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                SaveFileAsText(sb, save);
                return;
            }
            xlApp.Visible = false;

            Excel.Workbook wb = xlApp.Workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];

            if (ws == null)
            {


            }
            string[] delim = { Environment.NewLine, "\n" };
            string[] lines = sb.ToString().Split(delim, StringSplitOptions.None);

            int i = 1;
            foreach (string line in lines)
            {
                if (line.StartsWith("Question:"))
                {
                    //Excel.Range rng = ws.get_Range("A1", Missing.Value);

                    //rng.EntireColumn.Insert(Excel.XlInsertShiftDirection.xlShiftToRight,
                    //                       Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);
                    ws.Cells[1, i] = line.Replace("Question:", "");
                    i++;

                }
                else if (line.StartsWith("Answer:"))
                {
                    ws.Cells[2, i - 1] = line.Replace("Answer:", "");
                }


            }
            wb.SaveAs(save.FileName, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlApp.DisplayAlerts = true;
            wb.Close(true, misValue, misValue);
            xlApp.Quit();

        }

        private static void SaveFileAsText(StringBuilder sb, SaveFileDialog save)
        {
            StreamWriter writer = new StreamWriter(save.OpenFile());
            writer.WriteLine(sb.ToString());
            writer.Dispose();
            writer.Close();
        }
    }
}

