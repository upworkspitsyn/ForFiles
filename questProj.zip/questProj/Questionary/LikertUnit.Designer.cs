﻿namespace Questionary
{
    partial class LikertUnit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.luText = new System.Windows.Forms.TextBox();
            this.checkButton = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // luText
            // 
            this.luText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.luText.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.luText.Location = new System.Drawing.Point(0, 43);
            this.luText.Multiline = true;
            this.luText.Name = "luText";
            this.luText.Size = new System.Drawing.Size(153, 56);
            this.luText.TabIndex = 1;
            // 
            // checkButton
            // 
            this.checkButton.AutoSize = true;
            this.checkButton.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.checkButton.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.checkButton.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.checkButton.FlatAppearance.BorderSize = 0;
            this.checkButton.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.Control;
            this.checkButton.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.checkButton.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.checkButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.checkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkButton.ForeColor = System.Drawing.Color.Black;
            this.checkButton.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.checkButton.Location = new System.Drawing.Point(0, 0);
            this.checkButton.Name = "checkButton";
            this.checkButton.Size = new System.Drawing.Size(153, 17);
            this.checkButton.TabIndex = 2;
            this.checkButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.checkButton.UseVisualStyleBackColor = false;
            this.checkButton.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // LikertUnit
            // 
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.checkButton);
            this.Controls.Add(this.luText);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "LikertUnit";
            this.Size = new System.Drawing.Size(153, 99);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox luText;
        private System.Windows.Forms.CheckBox checkButton;
    }
}
