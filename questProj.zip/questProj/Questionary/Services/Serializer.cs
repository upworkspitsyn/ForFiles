﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace Questionary.Services
{
    class Serializer
    {
        public CustomForm DeserializeFromXML(string pathToXML)
        {
            XmlSerializer deserializer = new XmlSerializer(typeof(CustomForm));
            using (TextReader reader = new StreamReader(pathToXML))
            {
                object obj = deserializer.Deserialize(reader);
                CustomForm xmlData = (CustomForm)obj;
                return xmlData;
            }
        }
    }
}
