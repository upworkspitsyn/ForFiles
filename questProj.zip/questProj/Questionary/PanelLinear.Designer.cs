﻿namespace Questionary
{
    partial class PanelLinear
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStripEdit = new System.Windows.Forms.MenuStrip();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moFontLabel = new System.Windows.Forms.ToolStripMenuItem();
            this.moFontResponse = new System.Windows.Forms.ToolStripMenuItem();
            this.moTextAlign = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.centerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtQuestionText = new System.Windows.Forms.TextBox();
            this.flpResponse = new System.Windows.Forms.FlowLayoutPanel();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.menuStripEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripEdit
            // 
            this.menuStripEdit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.menuStripEdit.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStripEdit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontToolStripMenuItem,
            this.moTextAlign,
            this.borderToolStripMenuItem});
            this.menuStripEdit.Location = new System.Drawing.Point(0, 0);
            this.menuStripEdit.Name = "menuStripEdit";
            this.menuStripEdit.Size = new System.Drawing.Size(900, 33);
            this.menuStripEdit.TabIndex = 7;
            this.menuStripEdit.Text = "menuStrip1";
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.moFontLabel,
            this.moFontResponse});
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(60, 29);
            this.fontToolStripMenuItem.Text = "Font";
            this.fontToolStripMenuItem.ToolTipText = "Set font for Question Title and Response buttons";
            // 
            // moFontLabel
            // 
            this.moFontLabel.Name = "moFontLabel";
            this.moFontLabel.Size = new System.Drawing.Size(211, 30);
            this.moFontLabel.Text = "Label";
            this.moFontLabel.Click += new System.EventHandler(this.moFontLabel_Click);
            // 
            // moFontResponse
            // 
            this.moFontResponse.Name = "moFontResponse";
            this.moFontResponse.Size = new System.Drawing.Size(211, 30);
            this.moFontResponse.Text = "Response";
            this.moFontResponse.Click += new System.EventHandler(this.moFontResponse_Click);
            // 
            // moTextAlign
            // 
            this.moTextAlign.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftToolStripMenuItem,
            this.rightToolStripMenuItem,
            this.centerToolStripMenuItem});
            this.moTextAlign.Name = "moTextAlign";
            this.moTextAlign.Size = new System.Drawing.Size(102, 29);
            this.moTextAlign.Text = "Text-Align";
            this.moTextAlign.ToolTipText = "Set Alignment for the test of the question";
            this.moTextAlign.Click += new System.EventHandler(this.moTextAlign_Click);
            // 
            // leftToolStripMenuItem
            // 
            this.leftToolStripMenuItem.Name = "leftToolStripMenuItem";
            this.leftToolStripMenuItem.Size = new System.Drawing.Size(148, 30);
            this.leftToolStripMenuItem.Text = "Left";
            // 
            // rightToolStripMenuItem
            // 
            this.rightToolStripMenuItem.Name = "rightToolStripMenuItem";
            this.rightToolStripMenuItem.Size = new System.Drawing.Size(148, 30);
            this.rightToolStripMenuItem.Text = "Right";
            // 
            // centerToolStripMenuItem
            // 
            this.centerToolStripMenuItem.Name = "centerToolStripMenuItem";
            this.centerToolStripMenuItem.Size = new System.Drawing.Size(148, 30);
            this.centerToolStripMenuItem.Text = "Center";
            // 
            // borderToolStripMenuItem
            // 
            this.borderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noneToolStripMenuItem,
            this.singleToolStripMenuItem,
            this.singleDToolStripMenuItem});
            this.borderToolStripMenuItem.Name = "borderToolStripMenuItem";
            this.borderToolStripMenuItem.Size = new System.Drawing.Size(77, 29);
            this.borderToolStripMenuItem.Text = "Border";
            this.borderToolStripMenuItem.Click += new System.EventHandler(this.borderToolStripMenuItem_Click);
            // 
            // noneToolStripMenuItem
            // 
            this.noneToolStripMenuItem.Name = "noneToolStripMenuItem";
            this.noneToolStripMenuItem.Size = new System.Drawing.Size(173, 30);
            this.noneToolStripMenuItem.Text = "None";
            // 
            // singleToolStripMenuItem
            // 
            this.singleToolStripMenuItem.Name = "singleToolStripMenuItem";
            this.singleToolStripMenuItem.Size = new System.Drawing.Size(173, 30);
            this.singleToolStripMenuItem.Text = "Single";
            // 
            // singleDToolStripMenuItem
            // 
            this.singleDToolStripMenuItem.Name = "singleDToolStripMenuItem";
            this.singleDToolStripMenuItem.Size = new System.Drawing.Size(173, 30);
            this.singleDToolStripMenuItem.Text = "Single 3D";
            // 
            // txtQuestionText
            // 
            this.txtQuestionText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtQuestionText.Location = new System.Drawing.Point(3, 55);
            this.txtQuestionText.Multiline = true;
            this.txtQuestionText.Name = "txtQuestionText";
            this.txtQuestionText.Size = new System.Drawing.Size(859, 34);
            this.txtQuestionText.TabIndex = 8;
            this.txtQuestionText.Text = "Enter Question Text";
            // 
            // flpResponse
            // 
            this.flpResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.flpResponse.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.flpResponse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flpResponse.Location = new System.Drawing.Point(3, 121);
            this.flpResponse.Name = "flpResponse";
            this.flpResponse.Size = new System.Drawing.Size(860, 100);
            this.flpResponse.TabIndex = 9;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDelete.Location = new System.Drawing.Point(828, 0);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(35, 35);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "x";
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAdd.Location = new System.Drawing.Point(785, 0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(35, 35);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "+";
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // PanelLinear
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.flpResponse);
            this.Controls.Add(this.txtQuestionText);
            this.Controls.Add(this.menuStripEdit);
            this.Name = "PanelLinear";
            this.Size = new System.Drawing.Size(900, 260);
            this.menuStripEdit.ResumeLayout(false);
            this.menuStripEdit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripEdit;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moFontLabel;
        private System.Windows.Forms.ToolStripMenuItem moFontResponse;
        private System.Windows.Forms.ToolStripMenuItem moTextAlign;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem centerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleDToolStripMenuItem;
        private System.Windows.Forms.TextBox txtQuestionText;
        private System.Windows.Forms.FlowLayoutPanel flpResponse;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
    }
}
