﻿using System;
using System.IO;
using System.Windows.Forms;
using Questionary.Services;

namespace Questionary
{
    public partial class AnswersFormat : Form
    {
        private string _questName;
        public AnswersFormat()
        {
            InitializeComponent();
        }
        public AnswersFormat(string questName)
        {
            InitializeComponent();
            _questName = questName;
        }


        private void SelectFormat_Click(object sender, EventArgs e)
        {

        }

        private void CSV_Click(object sender, EventArgs e)
        {
            this.Close();
            SaveHTML("csv");
            
        }

        private void TXT_Click(object sender, EventArgs e)
        {
            this.Close();
            SaveHTML("txt");
            
        }

        private void SaveHTML(string answersFormat)
        {
            string sourcePath = Application.StartupPath + "\\tests";
            string sourceFile = System.IO.Path.Combine(sourcePath, _questName + ".xml");
            var converter = new ConverterService(new Serializer());
            var content = converter.HTMLCreator(sourceFile, answersFormat);
            SaveFileDialog save = new SaveFileDialog();
            save.FileName = _questName + ".html";
            if (save.ShowDialog() == DialogResult.OK)
            {
                string destFile = Path.Combine(Path.GetFullPath(save.FileName), save.FileName);
                File.WriteAllText(destFile, content);
            }
        }
    }
}
