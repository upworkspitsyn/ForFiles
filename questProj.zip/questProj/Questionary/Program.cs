﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questionary
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new OnStartForm());
            if (!Directory.Exists(Application.StartupPath + "\\tests"))
            { Directory.CreateDirectory(Application.StartupPath + "\\tests"); }
          
            Application.Run(new OnStartForm());
            MyForm form = new MyForm();
            Control obj = new Label();
            obj.Text = "Test";
            form.Controls.Add(obj);
        }
    }
}
