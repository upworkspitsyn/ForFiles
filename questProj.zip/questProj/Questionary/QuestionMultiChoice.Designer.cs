﻿namespace Questionary
{
    partial class QuestionMultiChoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuestionMultiChoice));
            this.lblQuestionNum = new System.Windows.Forms.Label();
            this.lblResponseType = new System.Windows.Forms.Label();
            this.pResponse = new System.Windows.Forms.Panel();
            this.chbxWrap = new System.Windows.Forms.CheckBox();
            this.txtOptiontxt = new System.Windows.Forms.TextBox();
            this.cbFlowDirection = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAddResp = new System.Windows.Forms.Button();
            this.flpResponse = new System.Windows.Forms.FlowLayoutPanel();
            this.txtQuestionLabel = new System.Windows.Forms.TextBox();
            this.menuTextResponce = new System.Windows.Forms.MenuStrip();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.option1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.option2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.option3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.option4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontsizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.fontstyleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.boldToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.italicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.boldItalicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textalignToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.middleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.withBorderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.withoutBorderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.withoutBorderToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rdbEditLabel = new System.Windows.Forms.RadioButton();
            this.rdbEditText = new System.Windows.Forms.RadioButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.formToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addQuestionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editHeaderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textAlignToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editResponseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.pResponse.SuspendLayout();
            this.menuTextResponce.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblQuestionNum
            // 
            this.lblQuestionNum.AutoSize = true;
            this.lblQuestionNum.BackColor = System.Drawing.Color.White;
            this.lblQuestionNum.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestionNum.Location = new System.Drawing.Point(31, 41);
            this.lblQuestionNum.Name = "lblQuestionNum";
            this.lblQuestionNum.Size = new System.Drawing.Size(274, 34);
            this.lblQuestionNum.TabIndex = 2;
            this.lblQuestionNum.Text = "Question Number ";
            // 
            // lblResponseType
            // 
            this.lblResponseType.AutoSize = true;
            this.lblResponseType.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponseType.Location = new System.Drawing.Point(462, 41);
            this.lblResponseType.Name = "lblResponseType";
            this.lblResponseType.Size = new System.Drawing.Size(414, 34);
            this.lblResponseType.TabIndex = 3;
            this.lblResponseType.Text = "Responce Type: MultiChoice";
            // 
            // pResponse
            // 
            this.pResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pResponse.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pResponse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pResponse.Controls.Add(this.chbxWrap);
            this.pResponse.Controls.Add(this.txtOptiontxt);
            this.pResponse.Controls.Add(this.cbFlowDirection);
            this.pResponse.Controls.Add(this.button1);
            this.pResponse.Controls.Add(this.btnAddResp);
            this.pResponse.Controls.Add(this.flpResponse);
            this.pResponse.Controls.Add(this.txtQuestionLabel);
            this.pResponse.Controls.Add(this.menuTextResponce);
            this.pResponse.Location = new System.Drawing.Point(35, 121);
            this.pResponse.Name = "pResponse";
            this.pResponse.Size = new System.Drawing.Size(1029, 511);
            this.pResponse.TabIndex = 11;
            // 
            // chbxWrap
            // 
            this.chbxWrap.AutoSize = true;
            this.chbxWrap.Location = new System.Drawing.Point(634, 211);
            this.chbxWrap.Name = "chbxWrap";
            this.chbxWrap.Size = new System.Drawing.Size(73, 24);
            this.chbxWrap.TabIndex = 9;
            this.chbxWrap.Text = "Wrap";
            this.chbxWrap.UseVisualStyleBackColor = true;
            this.chbxWrap.CheckedChanged += new System.EventHandler(this.chbxWrap_Click);
            // 
            // txtOptiontxt
            // 
            this.txtOptiontxt.Location = new System.Drawing.Point(142, 207);
            this.txtOptiontxt.Multiline = true;
            this.txtOptiontxt.Name = "txtOptiontxt";
            this.txtOptiontxt.Size = new System.Drawing.Size(472, 28);
            this.txtOptiontxt.TabIndex = 8;
            this.txtOptiontxt.Text = "Enter Option Text here";
            // 
            // cbFlowDirection
            // 
            this.cbFlowDirection.FormattingEnabled = true;
            this.cbFlowDirection.Items.AddRange(new object[] {
            "Bottom Up",
            "Right To Left",
            "Left To Right",
            "Top Down"});
            this.cbFlowDirection.Location = new System.Drawing.Point(23, 207);
            this.cbFlowDirection.Name = "cbFlowDirection";
            this.cbFlowDirection.Size = new System.Drawing.Size(113, 28);
            this.cbFlowDirection.TabIndex = 7;
            this.cbFlowDirection.Text = "Direction";
            this.cbFlowDirection.SelectedIndexChanged += new System.EventHandler(this.cbFlowDirection_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(804, 207);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 37);
            this.button1.TabIndex = 5;
            this.button1.Text = "-";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAddResp
            // 
            this.btnAddResp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddResp.Location = new System.Drawing.Point(723, 209);
            this.btnAddResp.Name = "btnAddResp";
            this.btnAddResp.Size = new System.Drawing.Size(55, 35);
            this.btnAddResp.TabIndex = 4;
            this.btnAddResp.Text = "+";
            this.btnAddResp.UseVisualStyleBackColor = true;
            this.btnAddResp.Click += new System.EventHandler(this.btnAddResp_Click);
            // 
            // flpResponse
            // 
            this.flpResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpResponse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpResponse.Location = new System.Drawing.Point(23, 250);
            this.flpResponse.Name = "flpResponse";
            this.flpResponse.Size = new System.Drawing.Size(977, 230);
            this.flpResponse.TabIndex = 3;
            // 
            // txtQuestionLabel
            // 
            this.txtQuestionLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtQuestionLabel.Location = new System.Drawing.Point(23, 88);
            this.txtQuestionLabel.Multiline = true;
            this.txtQuestionLabel.Name = "txtQuestionLabel";
            this.txtQuestionLabel.Size = new System.Drawing.Size(977, 77);
            this.txtQuestionLabel.TabIndex = 2;
            this.txtQuestionLabel.Text = "Enter Question Here";
            // 
            // menuTextResponce
            // 
            this.menuTextResponce.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuTextResponce.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuTextResponce.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuTextResponce.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontToolStripMenuItem,
            this.fontsizeToolStripMenuItem,
            this.fontstyleToolStripMenuItem,
            this.textalignToolStripMenuItem,
            this.borderToolStripMenuItem});
            this.menuTextResponce.Location = new System.Drawing.Point(0, 0);
            this.menuTextResponce.Name = "menuTextResponce";
            this.menuTextResponce.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuTextResponce.Size = new System.Drawing.Size(1025, 37);
            this.menuTextResponce.TabIndex = 1;
            this.menuTextResponce.Text = "menuStrip1";
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.option1ToolStripMenuItem,
            this.option2ToolStripMenuItem,
            this.option3ToolStripMenuItem,
            this.option4ToolStripMenuItem});
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(72, 33);
            this.fontToolStripMenuItem.Text = "font";
            this.fontToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.fontToolStripMenuItem_DropDownItemClicked);
            // 
            // option1ToolStripMenuItem
            // 
            this.option1ToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.option1ToolStripMenuItem.Name = "option1ToolStripMenuItem";
            this.option1ToolStripMenuItem.Size = new System.Drawing.Size(317, 30);
            this.option1ToolStripMenuItem.Text = "Times New Roman";
            // 
            // option2ToolStripMenuItem
            // 
            this.option2ToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.option2ToolStripMenuItem.Name = "option2ToolStripMenuItem";
            this.option2ToolStripMenuItem.Size = new System.Drawing.Size(317, 30);
            this.option2ToolStripMenuItem.Text = "Verdana";
            // 
            // option3ToolStripMenuItem
            // 
            this.option3ToolStripMenuItem.Font = new System.Drawing.Font("Blackadder ITC", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.option3ToolStripMenuItem.Name = "option3ToolStripMenuItem";
            this.option3ToolStripMenuItem.Size = new System.Drawing.Size(317, 30);
            this.option3ToolStripMenuItem.Text = "Blackadder ITC";
            // 
            // option4ToolStripMenuItem
            // 
            this.option4ToolStripMenuItem.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.option4ToolStripMenuItem.Name = "option4ToolStripMenuItem";
            this.option4ToolStripMenuItem.Size = new System.Drawing.Size(317, 30);
            this.option4ToolStripMenuItem.Text = "MS Reference Sans Serif";
            // 
            // fontsizeToolStripMenuItem
            // 
            this.fontsizeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
            this.fontsizeToolStripMenuItem.Name = "fontsizeToolStripMenuItem";
            this.fontsizeToolStripMenuItem.Size = new System.Drawing.Size(129, 33);
            this.fontsizeToolStripMenuItem.Text = "font-size";
            this.fontsizeToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.fontsizeToolStripMenuItem_DropDownItemClicked);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(129, 34);
            this.toolStripMenuItem2.Text = "8";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(129, 34);
            this.toolStripMenuItem3.Text = "10";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(129, 34);
            this.toolStripMenuItem4.Text = "12";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(129, 34);
            this.toolStripMenuItem5.Text = "14";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(129, 34);
            this.toolStripMenuItem6.Text = "16";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(129, 34);
            this.toolStripMenuItem7.Text = "20";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(129, 34);
            this.toolStripMenuItem8.Text = "22";
            // 
            // fontstyleToolStripMenuItem
            // 
            this.fontstyleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regularToolStripMenuItem,
            this.boldToolStripMenuItem,
            this.italicToolStripMenuItem,
            this.boldItalicToolStripMenuItem});
            this.fontstyleToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fontstyleToolStripMenuItem.Name = "fontstyleToolStripMenuItem";
            this.fontstyleToolStripMenuItem.Size = new System.Drawing.Size(139, 33);
            this.fontstyleToolStripMenuItem.Text = "font-style";
            this.fontstyleToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.fontstyleToolStripMenuItem_DropDownItemClicked);
            // 
            // regularToolStripMenuItem
            // 
            this.regularToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regularToolStripMenuItem.Name = "regularToolStripMenuItem";
            this.regularToolStripMenuItem.Size = new System.Drawing.Size(185, 30);
            this.regularToolStripMenuItem.Text = "regular";
            // 
            // boldToolStripMenuItem
            // 
            this.boldToolStripMenuItem.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boldToolStripMenuItem.Name = "boldToolStripMenuItem";
            this.boldToolStripMenuItem.Size = new System.Drawing.Size(185, 30);
            this.boldToolStripMenuItem.Text = "bold";
            // 
            // italicToolStripMenuItem
            // 
            this.italicToolStripMenuItem.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.italicToolStripMenuItem.Name = "italicToolStripMenuItem";
            this.italicToolStripMenuItem.Size = new System.Drawing.Size(185, 30);
            this.italicToolStripMenuItem.Text = "italic";
            // 
            // boldItalicToolStripMenuItem
            // 
            this.boldItalicToolStripMenuItem.Font = new System.Drawing.Font("Trebuchet MS", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boldItalicToolStripMenuItem.Name = "boldItalicToolStripMenuItem";
            this.boldItalicToolStripMenuItem.Size = new System.Drawing.Size(185, 30);
            this.boldItalicToolStripMenuItem.Text = "bold italic";
            // 
            // textalignToolStripMenuItem
            // 
            this.textalignToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rightToolStripMenuItem,
            this.leftToolStripMenuItem,
            this.middleToolStripMenuItem});
            this.textalignToolStripMenuItem.Name = "textalignToolStripMenuItem";
            this.textalignToolStripMenuItem.Size = new System.Drawing.Size(138, 33);
            this.textalignToolStripMenuItem.Text = "text-align";
            this.textalignToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.textalignToolStripMenuItem_DropDownItemClicked);
            // 
            // rightToolStripMenuItem
            // 
            this.rightToolStripMenuItem.Name = "rightToolStripMenuItem";
            this.rightToolStripMenuItem.Size = new System.Drawing.Size(174, 34);
            this.rightToolStripMenuItem.Text = "Right";
            // 
            // leftToolStripMenuItem
            // 
            this.leftToolStripMenuItem.Name = "leftToolStripMenuItem";
            this.leftToolStripMenuItem.Size = new System.Drawing.Size(174, 34);
            this.leftToolStripMenuItem.Text = "Left";
            // 
            // middleToolStripMenuItem
            // 
            this.middleToolStripMenuItem.Name = "middleToolStripMenuItem";
            this.middleToolStripMenuItem.Size = new System.Drawing.Size(174, 34);
            this.middleToolStripMenuItem.Text = "Center";
            // 
            // borderToolStripMenuItem
            // 
            this.borderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.withBorderToolStripMenuItem,
            this.withoutBorderToolStripMenuItem,
            this.withoutBorderToolStripMenuItem1});
            this.borderToolStripMenuItem.Name = "borderToolStripMenuItem";
            this.borderToolStripMenuItem.Size = new System.Drawing.Size(104, 33);
            this.borderToolStripMenuItem.Text = "border";
            this.borderToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.borderToolStripMenuItem_DropDownItemClicked);
            // 
            // withBorderToolStripMenuItem
            // 
            this.withBorderToolStripMenuItem.Name = "withBorderToolStripMenuItem";
            this.withBorderToolStripMenuItem.Size = new System.Drawing.Size(275, 34);
            this.withBorderToolStripMenuItem.Text = "Single";
            // 
            // withoutBorderToolStripMenuItem
            // 
            this.withoutBorderToolStripMenuItem.Name = "withoutBorderToolStripMenuItem";
            this.withoutBorderToolStripMenuItem.Size = new System.Drawing.Size(275, 34);
            this.withoutBorderToolStripMenuItem.Text = "Single 3D";
            // 
            // withoutBorderToolStripMenuItem1
            // 
            this.withoutBorderToolStripMenuItem1.Name = "withoutBorderToolStripMenuItem1";
            this.withoutBorderToolStripMenuItem1.Size = new System.Drawing.Size(275, 34);
            this.withoutBorderToolStripMenuItem1.Text = "None";
            // 
            // rdbEditLabel
            // 
            this.rdbEditLabel.AutoSize = true;
            this.rdbEditLabel.Location = new System.Drawing.Point(37, 91);
            this.rdbEditLabel.Name = "rdbEditLabel";
            this.rdbEditLabel.Size = new System.Drawing.Size(105, 24);
            this.rdbEditLabel.TabIndex = 12;
            this.rdbEditLabel.TabStop = true;
            this.rdbEditLabel.Text = "Edit Label";
            this.rdbEditLabel.UseVisualStyleBackColor = true;
            this.rdbEditLabel.CheckedChanged += new System.EventHandler(this.rdbEditLabel_CheckedChanged);
            // 
            // rdbEditText
            // 
            this.rdbEditText.AutoSize = true;
            this.rdbEditText.Location = new System.Drawing.Point(468, 91);
            this.rdbEditText.Name = "rdbEditText";
            this.rdbEditText.Size = new System.Drawing.Size(139, 24);
            this.rdbEditText.TabIndex = 13;
            this.rdbEditText.TabStop = true;
            this.rdbEditText.Text = "Edit Response";
            this.rdbEditText.UseVisualStyleBackColor = true;
            this.rdbEditText.CheckedChanged += new System.EventHandler(this.rdbEditText_CheckedChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1124, 33);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // formToolStripMenuItem
            // 
            this.formToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addQuestionToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.previewToolStripMenuItem});
            this.formToolStripMenuItem.Name = "formToolStripMenuItem";
            this.formToolStripMenuItem.Size = new System.Drawing.Size(66, 29);
            this.formToolStripMenuItem.Text = "Form";
            // 
            // addQuestionToolStripMenuItem
            // 
            //this.addQuestionToolStripMenuItem.Name = "addQuestionToolStripMenuItem";
            //this.addQuestionToolStripMenuItem.Size = new System.Drawing.Size(208, 30);
            //this.addQuestionToolStripMenuItem.Text = "Add Question";
            //this.addQuestionToolStripMenuItem.Click += new System.EventHandler(this.addQuestionToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(208, 30);
            this.closeToolStripMenuItem.Text = "Close";
            // 
            // previewToolStripMenuItem
            // 
            this.previewToolStripMenuItem.Name = "previewToolStripMenuItem";
            this.previewToolStripMenuItem.Size = new System.Drawing.Size(208, 30);
            this.previewToolStripMenuItem.Text = "Preview";
            this.previewToolStripMenuItem.Click += new System.EventHandler(this.previewToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editHeaderToolStripMenuItem,
            this.editResponseToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(64, 29);
            this.editToolStripMenuItem.Text = "Edit  ";
            // 
            // editHeaderToolStripMenuItem
            // 
            this.editHeaderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontToolStripMenuItem1,
            this.textAlignToolStripMenuItem1});
            this.editHeaderToolStripMenuItem.Name = "editHeaderToolStripMenuItem";
            this.editHeaderToolStripMenuItem.Size = new System.Drawing.Size(239, 30);
            this.editHeaderToolStripMenuItem.Text = "Edit Question Text";
            // 
            // fontToolStripMenuItem1
            // 
            this.fontToolStripMenuItem1.Name = "fontToolStripMenuItem1";
            this.fontToolStripMenuItem1.Size = new System.Drawing.Size(175, 30);
            this.fontToolStripMenuItem1.Text = "Font";
            // 
            // textAlignToolStripMenuItem1
            // 
            this.textAlignToolStripMenuItem1.Name = "textAlignToolStripMenuItem1";
            this.textAlignToolStripMenuItem1.Size = new System.Drawing.Size(175, 30);
            this.textAlignToolStripMenuItem1.Text = "Text-Align";
            // 
            // editResponseToolStripMenuItem
            // 
            this.editResponseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontToolStripMenuItem2});
            this.editResponseToolStripMenuItem.Name = "editResponseToolStripMenuItem";
            this.editResponseToolStripMenuItem.Size = new System.Drawing.Size(239, 30);
            this.editResponseToolStripMenuItem.Text = "Edit Response";
            // 
            // fontToolStripMenuItem2
            // 
            this.fontToolStripMenuItem2.Name = "fontToolStripMenuItem2";
            this.fontToolStripMenuItem2.Size = new System.Drawing.Size(133, 30);
            this.fontToolStripMenuItem2.Text = "Font";
            // 
            // QuestionMultiChoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1124, 644);
            this.Controls.Add(this.rdbEditText);
            this.Controls.Add(this.rdbEditLabel);
            this.Controls.Add(this.pResponse);
            this.Controls.Add(this.lblResponseType);
            this.Controls.Add(this.lblQuestionNum);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "QuestionMultiChoice";
            this.Text = "QuestionMultiChoice";
            this.pResponse.ResumeLayout(false);
            this.pResponse.PerformLayout();
            this.menuTextResponce.ResumeLayout(false);
            this.menuTextResponce.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuestionNum;
        private System.Windows.Forms.Label lblResponseType;
        private System.Windows.Forms.Panel pResponse;
        private System.Windows.Forms.TextBox txtQuestionLabel;
        private System.Windows.Forms.MenuStrip menuTextResponce;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem option1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem option2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem option3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem option4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontsizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem fontstyleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem boldToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem italicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem boldItalicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textalignToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem middleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem withBorderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem withoutBorderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem withoutBorderToolStripMenuItem1;
        private System.Windows.Forms.FlowLayoutPanel flpResponse;
        private System.Windows.Forms.Button btnAddResp;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbFlowDirection;
        private System.Windows.Forms.TextBox txtOptiontxt;
        private System.Windows.Forms.CheckBox chbxWrap;
        private System.Windows.Forms.RadioButton rdbEditLabel;
        private System.Windows.Forms.RadioButton rdbEditText;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem formToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addQuestionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editHeaderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem textAlignToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editResponseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem2;
    }
}