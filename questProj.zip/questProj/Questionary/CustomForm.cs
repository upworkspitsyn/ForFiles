﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Questionary
{
    public class CustomForm
    {

        public Size ThisForm { get; set; }

        public FormHeader Header { get; set; }
        public class FormHeader 
        { 
            public CommonSettings Settings { get; set; }
            public HeaderText HeaderTextString { get; set; }

            public class HeaderText
            {
                public CommonSettings Settings { get; set; }
            }
        }
       
    public Body FormBody { get; set; }

        public class Body 
        {
           
            public CommonSettings Settings { get; set; }
            public List<Response> Responses { get; set; }
            public class QuestTitle
            {
                public CommonSettings Settings { get; set; }

            }
            public Response QuestResponse { get; set; }

            public class Response
            {
                public CommonSettings Settings { get; set; }
                public List<MyControl> Controls { get; set; }
                public int QuestionNumber { get; set; }
                public bool Required { get; set; }
                public QuestTitle QuestionTitle { get; set; }
                public string QuestVarName { get; set; }
                public string Type { get; set; }

                public class MyControl
                {
                    public string Type { get; set; }
                    public string Number { get; set; }
                    public CommonSettings Settings { get; set; }
                    public bool isChecked { get; set; }
                    public ContentAlignment CheckAlign { get; set; }
                    public Color ScaleColor { get; set; }
                    public List<string> ItemList { get; set; } 

                }
            }
        }
    }
     
    public class CommonSettings
    { //TODO: add location?
        public string TextValue { get; set; }
        public SeriFont font { get; set; }
        public BorderStyle BorderStyle { get; set; }
        public AnchorStyles Anchor { get; set; }
        public string BackColor { get; set; }
        public int Test { get; set; }
        public string ForeColor { get; set; }
        public bool AutoSize { get; set; }
        public bool AutoScroll { get; set; }
        public FlowDirection FlowDorection { get; set; }
        public Size Size { get; set; }
        public bool WrapContent { get; set; }
        public HorizontalAlignment TextAlign { get; set; }
        public AutoSizeMode AutoSizeMode { get; set;}
        public Point Location { get; set; }
    }

    public class SeriFont
    {
        public string FontFamily { get; set; }
        public GraphicsUnit GraphicsUnit { get; set; }
        public float Size { get; set; }
        public FontStyle Style { get; set; }
    }
}
